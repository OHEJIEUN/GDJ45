package phone;

public class Phone {

}
